#!/usr/bin/env bash
set -euo pipefail
unset HUSKY
if ! command -v node >/dev/null || [ "$(node -v)" != v24.22.1 ]; then
 mkdir -p "$HOME/.node"
 curl -fsSL --connect-timeout 15 --max-time 180 https://nodejs.org/dist/v24.22.1/node-v24.22.1-linux-x64.tar.gz -o /work/crabbox/node24.tar.gz
 curl -fsSL --max-time 30 https://nodejs.org/dist/v24.22.1/SHASUMS256.txt -o /work/crabbox/node24-sha.txt
 awk '$2 == "node-v24.22.1-linux-x64.tar.gz" {print $1 "  /work/crabbox/node24.tar.gz"}' /work/crabbox/node24-sha.txt | sha256sum -c -
 tar -xzf /work/crabbox/node24.tar.gz -C "$HOME/.node" --strip-components=1
 export PATH="$HOME/.node/bin:$PATH"
fi
node -v; npm -v; test "$(uname -m)" = x86_64
echo CRABBOX_PHASE:verify-payload
echo "e57fa15a8b0bb37a2cfa4100dae001eb2c7069d67da76cabf5847ebdc147c84d  verification-state/fork152-source.tar" | sha256sum -c -
echo "faecfa72faec1b6b5a69772cc0bd53d756d49b8bac1e61f2790051e62b576623  verification-state/fork152-metadata.tar.gz" | sha256sum -c -
test ! -e .git
tar -xf verification-state/fork152-source.tar --no-same-owner
tar -xzf verification-state/fork152-metadata.tar.gz --no-same-owner
mv fork152-verification.git .git
git read-tree HEAD
git add --pathspec-from-file=verification-state/fork152-paths.txt --pathspec-file-nul
test "$(git write-tree)" = 9c03ce00d9b2ad7d0b664b5f4b26278d1f1279d1
echo "2b6bfaae8c48f12050813c2ffe1884c61ea26e750d803df9c9114550a314cd14  verification-state/fd-v10.3.0-x86_64-unknown-linux-musl.tar.gz" | sha256sum -c -
mkdir -p "$HOME/.local/share/pi152-tools" "$HOME/.local/bin"
tar -xzf verification-state/fd-v10.3.0-x86_64-unknown-linux-musl.tar.gz -C "$HOME/.local/share/pi152-tools"
install -m755 "$HOME/.local/share/pi152-tools/fd-v10.3.0-x86_64-unknown-linux-musl/fd" "$HOME/.local/bin/fd"
export PATH="$HOME/.local/bin:$PATH"
fd --version
echo CRABBOX_PHASE:refresh-workspace-lock
npm install --package-lock-only --ignore-scripts --no-audit --no-fund --loglevel=error
node scripts/generate-coding-agent-install-lock.mjs
git add -- package-lock.json packages/coding-agent/install-lock/package.json packages/coding-agent/install-lock/package-lock.json
echo CRABBOX_PHASE:install
npm ci --ignore-scripts --prefer-offline --no-audit --no-fund --loglevel=error
echo CRABBOX_PHASE:hydrate-and-offline-build
npm run hydrate:model-snapshot
npm run build:offline
echo CRABBOX_PHASE:deterministic-targeted-tests
TEST_HOME=$(mktemp -d)
(cd packages/coding-agent && env -i PATH="$PATH" HOME="$TEST_HOME" VITEST_MAX_WORKERS=1 node ../../node_modules/vitest/dist/cli.js --run test/read-abort.test.ts test/read-streaming.test.ts test/interactive-mode-resume-missing-cwd.test.ts)
(cd packages/chord && env -i PATH="$PATH" HOME="$TEST_HOME" VITEST_MAX_WORKERS=1 node ../../node_modules/vitest/dist/cli.js --run test/node/app/app.test.ts test/host/host-data.test.ts test/store/host-data.test.ts)
(cd packages/ai && env -i PATH="$PATH" HOME="$TEST_HOME" VITEST_MAX_WORKERS=1 node ../../node_modules/vitest/dist/cli.js --run test/providers.test.ts)
node --test scripts/update-model-catalog-pin.test.mjs
(cd apps/p2 && env -i PATH="$PATH" HOME="$TEST_HOME" node --import ./src/source.ts --test --test-concurrency=1 test/p2/plugin-layout.test.ts test/p2/source-resolver.test.ts test/p2/views-layout.test.ts test/p2/views.test.ts test/p2/settings.test.ts)
echo CRABBOX_PHASE:commit-with-canonical-hook
mkdir -p .crabbox/commit-hooks
printf "%s\n" "#!/bin/sh" "exec /bin/sh .husky/pre-commit" > .crabbox/commit-hooks/pre-commit
chmod 755 .crabbox/commit-hooks/pre-commit
git config user.name Luke
git config user.email luke@bermont.digital
git -c core.hooksPath=.crabbox/commit-hooks commit -m "feat: merge upstream Pi 1.5.2"
test "$(git rev-parse HEAD^1)" = 994fbd6f3c038adf1c322719b7ff84f62ab290e2
test "$(git rev-parse HEAD^2)" = b4afdddf44e059c67ccf5097e5317d913521b470
git diff --exit-code
printf "COMMIT_HEAD=%s COMMIT_TREE=%s\n" "$(git rev-parse HEAD)" "$(git rev-parse HEAD^{tree})"
git bundle create verification-state/fork152-gates.bundle refs/heads/verification-candidate ^994fbd6f3c038adf1c322719b7ff84f62ab290e2 ^b4afdddf44e059c67ccf5097e5317d913521b470
sha256sum verification-state/fork152-gates.bundle
echo CRABBOX_PHASE:finished-status-0
