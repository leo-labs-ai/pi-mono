#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.node/bin:$HOME/.local/bin:$PATH"
unset HUSKY
test "$(git rev-parse HEAD)" = 5f4d72cfdc0be4d250885cbe55bfcf07d8235f13
test -z "$(git status --porcelain --untracked-files=no)"
git apply --index verification-state/read-abort-core.patch
test "$(git write-tree)" = 3e31c528a10b372799925ad78b07403621b25670
echo CRABBOX_PHASE:read-abort-tests
TEST_HOME=$(mktemp -d)
(cd packages/coding-agent && env -i PATH="$PATH" HOME="$TEST_HOME" VITEST_MAX_WORKERS=1 node ../../node_modules/vitest/dist/cli.js --run test/read-abort.test.ts test/read-streaming.test.ts)
echo CRABBOX_PHASE:commit-with-canonical-hook
git -c core.hooksPath=.crabbox/commit-hooks commit -m 'fix(coding-agent): own aborted read stream errors'
test "$(git rev-parse HEAD^{tree})" = 3e31c528a10b372799925ad78b07403621b25670
printf 'COMMIT_HEAD=%s COMMIT_TREE=%s\n' "$(git rev-parse HEAD)" "$(git rev-parse HEAD^{tree})"
git bundle create verification-state/read-abort-core.bundle refs/heads/verification-candidate ^5f4d72cfdc0be4d250885cbe55bfcf07d8235f13
sha256sum verification-state/read-abort-core.bundle
echo CRABBOX_PHASE:finished-status-0
