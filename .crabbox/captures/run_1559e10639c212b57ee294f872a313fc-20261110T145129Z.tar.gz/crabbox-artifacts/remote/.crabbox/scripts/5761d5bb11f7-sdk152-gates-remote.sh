#!/usr/bin/env bash
set -euo pipefail
unset HUSKY
export PATH="$HOME/.node/bin:$HOME/.local/bin:$PATH"
FORK=$PWD
D="$FORK/verification-state/sdk152-input"
W="$(dirname "$FORK")/my-pi"
(cd "$D" && sha256sum -c sdk152-inputs.sha256)
# This file contains public commit/tree expectations only, never credentials.
source "$D/sdk152-expectations.env"
test "$(node -v)" = v24.22.1
test "$(git rev-parse HEAD)" = "$FORK_SHA"
test "$(git rev-parse HEAD^{tree})" = "$FORK_TREE"
test -z "$(git status --porcelain --untracked-files=no)"
test ! -e "$W"
test ! -e "$(dirname "$FORK")/pi-mono-fork"
ln -s pi-mono "$(dirname "$FORK")/pi-mono-fork"
mkdir "$W"
tar -xf "$D/sdk152-base-source.tar" --no-same-owner -C "$W"
tar -xzf "$D/sdk152-verification.tar.gz" --no-same-owner -C "$W"
mv "$W/sdk152-verification.git" "$W/.git"
cd "$W"
test "$(git rev-parse HEAD)" = "$SDK_BASE"
test "$(git rev-parse origin/main)" = "$SDK_MAIN"
git read-tree HEAD
git update-index --refresh
echo CRABBOX_PHASE:merge-preserved-sdk-main
git merge --no-commit --no-ff origin/main
git apply --index "$D/sdk152-candidate.patch"
test "$(git write-tree)" = "$SDK_TREE"
printf "MY_PI_TREE=%s SDK_MAIN=%s FORK_HEAD=%s\n" "$SDK_TREE" "$SDK_MAIN" "$FORK_SHA"
echo CRABBOX_PHASE:fresh-sdk-dependencies
npm ci --prefer-offline --no-audit --no-fund --loglevel=error --ignore-scripts
echo CRABBOX_PHASE:pinned-native-prerequisites
bash "$D/sdk-toolchain-and-native.sh"
unset NODE_AUTH_TOKEN
RUNHOME=$(mktemp -d "$FORK/verification-state/sdk152-home.XXXXXX")
status=0
run_gate() {
  local label=$1
  shift
  echo "CRABBOX_PHASE:$label"
  if env -i PATH="$PATH" HOME="$RUNHOME" PI_CODING_AGENT_DIR="$RUNHOME/.pi/agent" NPM_CONFIG_USERCONFIG=/dev/null "$@"; then
    echo "CRABBOX_GATE:$label:PASS"
  else
    echo "CRABBOX_GATE:$label:FAIL"
    status=1
  fi
}
run_gate workspace-resolution npm run verify:workspace-resolution
run_gate otlp-build npm run build --workspace=@valkyriweb/pi-observability-extensions
run_gate workspace-typecheck npm run typecheck
run_gate lint npm run lint
run_gate scar-rules npm run lint:scars
run_gate goal-regressions npm run test:pi-goal
run_gate session-title-regressions node --test extensions/session-title/test/*.test.mjs
run_gate workflow-regressions node --test test/release-workflow.test.mjs test/agentic-review-baked-pi-version.test.mjs test/sdk-workflow-build-route.test.mjs
run_gate vanilla-launcher-regressions node --test test/vanilla-pi-launcher.test.mjs
run_gate vanilla-patch-regressions npm run test:vanilla-read-abort
run_gate portable-ci-baseline npm run gate:ci
echo CRABBOX_PHASE:full-extension-gate-deferred-to-mandatory-bridge-PR-CI
git diff --exit-code || status=1
test "$(git write-tree)" = "$SDK_TREE" || status=1
test "$(git -C "$FORK" rev-parse HEAD)" = "$FORK_SHA" || status=1
test -z "$(git -C "$FORK" status --porcelain --untracked-files=no)" || status=1
printf "SDK152_GATES_STATUS=%s MY_PI_TREE=%s SDK_HEAD=%s\n" "$status" "$SDK_TREE" "$FORK_SHA"
test "$status" = 0
echo CRABBOX_PHASE:normal-sdk-canonical-hook-commit
env -i PATH="$PATH" HOME="$RUNHOME" PI_CODING_AGENT_DIR="$RUNHOME/.pi/agent" NPM_CONFIG_USERCONFIG=/dev/null git -c core.hooksPath=hooks commit -m "feat: update Pi SDK and vanilla runtime to 1.5.2"
test "$(git rev-parse HEAD^1)" = "$SDK_BASE"
test "$(git rev-parse HEAD^2)" = "$SDK_MAIN"
test "$(git rev-parse HEAD^{tree})" = "$SDK_TREE"
git merge-base --is-ancestor 647e8f7c4fe72247458c115baad88825cc1d4c65 HEAD
git merge-base --is-ancestor 2f2c86da03c94bf04fe4fef0c5ae7d6ba7aaebf3 HEAD
git diff --exit-code
git diff --cached --exit-code
printf "SDK152_COMMIT_HEAD=%s COMMIT_TREE=%s\n" "$(git rev-parse HEAD)" "$SDK_TREE"
git bundle create "$FORK/verification-state/sdk152-gates.bundle" refs/heads/lue/t-pi-151-sdk-1110 ^"$SDK_BASE" ^"$SDK_MAIN"
sha256sum "$FORK/verification-state/sdk152-gates.bundle"
echo CRABBOX_PHASE:finished-status-0
