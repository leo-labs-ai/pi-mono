#!/usr/bin/env bash
set -euo pipefail
test "$(uname -m)" = x86_64
if ! command -v node >/dev/null; then
  mkdir -p "$HOME/.node"
  curl -fsSL --connect-timeout 15 --max-time 180 https://nodejs.org/dist/v24.22.1/node-v24.22.1-linux-x64.tar.gz | tar -xz -C "$HOME/.node" --strip-components=1
fi
export PATH="$HOME/.node/bin:$HOME/.local/bin:$PATH"
node -v
echo CRABBOX_PHASE:git-context
if [ -e .git ]; then
  mv .git .crabbox/git-before-verification
fi
tar -xzf verification-state/verification-git-metadata.tar.gz --no-same-owner
mv verification-git-metadata.git .git
git read-tree 94b0b09fe58d9ef2f8ca2be1523b0a5ac499d5df
git add -f --pathspec-from-file=verification-state/staged-paths.nul --pathspec-file-nul
expected=$(tr -d '\n' < verification-state/expected-tree.txt)
actual=$(git write-tree)
printf 'VERIFIED_TREE expected=%s actual=%s\n' "$expected" "$actual"
test "$actual" = "$expected"
echo CRABBOX_PHASE:fd-prerequisite
echo '2b6bfaae8c48f12050813c2ffe1884c61ea26e750d803df9c9114550a314cd14  verification-state/fd-v10.3.0-x86_64-unknown-linux-musl.tar.gz' | sha256sum -c -
mkdir -p "$HOME/.local/share/pi151-tools" "$HOME/.local/bin"
tar -xzf verification-state/fd-v10.3.0-x86_64-unknown-linux-musl.tar.gz -C "$HOME/.local/share/pi151-tools"
install -m755 "$HOME/.local/share/pi151-tools/fd-v10.3.0-x86_64-unknown-linux-musl/fd" "$HOME/.local/bin/fd"
fd --version
echo CRABBOX_PHASE:install
npm ci --prefer-offline --no-audit --no-fund --loglevel=error --ignore-scripts
echo CRABBOX_PHASE:hydrate
npm run hydrate:model-snapshot
echo CRABBOX_PHASE:build
npm run build:offline
status=0
echo CRABBOX_PHASE:check
npm run check || status=1
echo CRABBOX_PHASE:build-gate
GATE_HOME=$(mktemp -d)
env -i PATH="$PATH" HOME="$GATE_HOME" VITEST_MAX_WORKERS=1 PI_NO_LOCAL_LLM=1 AWS_EC2_METADATA_DISABLED=true npm run test:build-gate || status=1
echo CRABBOX_PHASE:anthropic-effort
ROOT=$PWD
(cd packages/ai && env -i PATH="$PATH" HOME="$GATE_HOME" VITEST_MAX_WORKERS=1 node "$ROOT/node_modules/vitest/dist/cli.js" --run test/anthropic-mid-conversation-effort.test.ts) || status=1
echo CRABBOX_PHASE:p2-check
(cd apps/p2 && npm run check) || status=1
echo CRABBOX_PHASE:p2-plugin-layout
(cd apps/p2 && env -i PATH="$PATH" HOME="$GATE_HOME" node --import ./src/source.ts --test test/p2/plugin-layout.test.ts) || status=1
echo CRABBOX_PHASE:payload-stability
git diff --exit-code || status=1
final=$(git write-tree)
printf 'FINAL_TREE expected=%s actual=%s\n' "$expected" "$final"
test "$final" = "$expected" || status=1
echo CRABBOX_PHASE:finished-status-$status
exit "$status"
