#!/usr/bin/env bash
set -euo pipefail
unset HUSKY
export PATH="$HOME/.node/bin:$HOME/.local/bin:$PATH"
test "$(node -v)" = v24.22.1
echo CRABBOX_PHASE:verify-reviewed-workspace-lock
echo "8508c0af3e043d0ba4f94860aed84b01de398f09e8ac526f9e1be3758d7b6154  package-lock.json" | sha256sum -c -
test "$(git write-tree)" = 74cd685eba68102f0bef394c9f3fc1ab69fa92d9
git diff --cached --quiet -- .pi/skills/p2-ui.md
echo CRABBOX_PHASE:normal-canonical-hook
# Reviewed only17 workspace metadata entries; no external packages or lifecycle scripts changed.
PI_ALLOW_LOCKFILE_CHANGE=1 git -c core.hooksPath=.crabbox/commit-hooks commit -m "feat: merge upstream Pi 1.5.2"
test "$(git rev-parse HEAD^1)" = 994fbd6f3c038adf1c322719b7ff84f62ab290e2
test "$(git rev-parse HEAD^2)" = b4afdddf44e059c67ccf5097e5317d913521b470
git diff --exit-code
printf "COMMIT_HEAD=%s COMMIT_TREE=%s\n" "$(git rev-parse HEAD)" "$(git rev-parse HEAD^{tree})"
git bundle create verification-state/fork152-gates.bundle refs/heads/verification-candidate ^994fbd6f3c038adf1c322719b7ff84f62ab290e2 ^b4afdddf44e059c67ccf5097e5317d913521b470
sha256sum verification-state/fork152-gates.bundle
echo CRABBOX_PHASE:finished-status-0
