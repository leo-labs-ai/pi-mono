#!/usr/bin/env bash
set -euo pipefail
unset HUSKY
export PATH="$HOME/.node/bin:$HOME/.local/bin:$PATH"
FORK=$PWD
D="$FORK/verification-state/sdk152-resume-input"
W="$(dirname "$FORK")/my-pi"
(cd "$D" && sha256sum -c sdk152-resume-inputs.sha256)
source "$D/sdk152-resume-expectations.env"
test "$(node -v)" = v24.22.1
test "$(git rev-parse HEAD)" = "$FORK_SHA"
test "$(git rev-parse HEAD^{tree})" = "$FORK_TREE"
test -z "$(git status --porcelain --untracked-files=no)"
cd "$W"
test "$(git rev-parse HEAD)" = "$SDK_BASE"
test "$(git rev-parse MERGE_HEAD)" = "$SDK_MAIN"
test "$(git write-tree)" = "$SDK_PREVIOUS_TREE"
git diff --exit-code
echo CRABBOX_PHASE:apply-typed-fixtures-and-final-head-pin
git apply --check --index "$D/sdk152-resume.patch"
git apply --index "$D/sdk152-resume.patch"
test "$(git write-tree)" = "$SDK_TREE"
printf "MY_PI_TREE=%s FORK_HEAD=%s\n" "$SDK_TREE" "$FORK_SHA"
echo CRABBOX_PHASE:retained-fresh-prerequisites
for tool in git python3 curl tar; do command -v "$tool"; done
test "$(node -p process.versions.modules)" = 137
test "$(bun --version)" = 1.4.2
test "$(node -p 'require("./package-lock.json").packages["node_modules/better-sqlite3"].version')" = 12.11.1
node -e 'const Database=require("better-sqlite3");const db=new Database(":memory:");db.close();console.log("SQLITE_NATIVE_LOAD_PASS=1")'
fd --version
echo CRABBOX_PHASE:jq-pinned-official-prerequisite
JQ_DIR="$FORK/verification-state/jq-1.8.1"
mkdir -p "$JQ_DIR" "$HOME/.local/bin"
curl -fsSL --connect-timeout 15 --max-time 180 https://github.com/jqlang/jq/releases/download/jq-1.8.1/jq-linux-amd64 -o "$JQ_DIR/jq-linux-amd64"
curl -fsSL --connect-timeout 15 --max-time 60 https://github.com/jqlang/jq/releases/download/jq-1.8.1/sha256sum.txt -o "$JQ_DIR/sha256sum.txt"
(cd "$JQ_DIR" && awk '$2 == "jq-linux-amd64" {print}' sha256sum.txt | sha256sum -c -)
install -m755 "$JQ_DIR/jq-linux-amd64" "$HOME/.local/bin/jq"
test "$(jq --version)" = jq-1.8.1
jq --version
unset NODE_AUTH_TOKEN
RUNHOME=$(mktemp -d "$FORK/verification-state/sdk152-home.XXXXXX")
status=0
run_gate() {
  local label=$1
  shift
  echo "CRABBOX_PHASE:$label"
  if env -i PATH="$PATH" HOME="$RUNHOME" PI_CODING_AGENT_DIR="$RUNHOME/.pi/agent" NPM_CONFIG_USERCONFIG=/dev/null "$@"; then
    echo "CRABBOX_GATE:$label:PASS"
  else
    echo "CRABBOX_GATE:$label:FAIL"
    status=1
  fi
}
run_gate workspace-resolution npm run verify:workspace-resolution
run_gate otlp-build npm run build --workspace=@valkyriweb/pi-observability-extensions
run_gate workspace-typecheck npm run typecheck
run_gate lint npm run lint
run_gate scar-rules npm run lint:scars
run_gate goal-regressions npm run test:pi-goal
run_gate session-title-regressions node --test extensions/session-title/test/*.test.mjs
run_gate workflow-regressions node --test test/release-workflow.test.mjs test/agentic-review-baked-pi-version.test.mjs test/sdk-workflow-build-route.test.mjs
run_gate vanilla-launcher-regressions node --test test/vanilla-pi-launcher.test.mjs
run_gate vanilla-patch-regressions npm run test:vanilla-read-abort
run_gate portable-ci-baseline npm run gate:ci
echo CRABBOX_PHASE:full-extension-gate-deferred-to-mandatory-bridge-PR-CI
git diff --exit-code || status=1
test "$(git write-tree)" = "$SDK_TREE" || status=1
test "$(git -C "$FORK" rev-parse HEAD)" = "$FORK_SHA" || status=1
test -z "$(git -C "$FORK" status --porcelain --untracked-files=no)" || status=1
printf "SDK152_GATES_STATUS=%s MY_PI_TREE=%s SDK_HEAD=%s\n" "$status" "$SDK_TREE" "$FORK_SHA"
test "$status" = 0
echo CRABBOX_PHASE:normal-sdk-canonical-hook-commit
env -i PATH="$PATH" HOME="$RUNHOME" PI_CODING_AGENT_DIR="$RUNHOME/.pi/agent" NPM_CONFIG_USERCONFIG=/dev/null git -c core.hooksPath=hooks commit -m "feat: update Pi SDK and vanilla runtime to 1.5.2"
test "$(git rev-parse HEAD^1)" = "$SDK_BASE"
test "$(git rev-parse HEAD^2)" = "$SDK_MAIN"
test "$(git rev-parse HEAD^{tree})" = "$SDK_TREE"
git merge-base --is-ancestor 647e8f7c4fe72247458c115baad88825cc1d4c65 HEAD
git merge-base --is-ancestor 2f2c86da03c94bf04fe4fef0c5ae7d6ba7aaebf3 HEAD
git diff --exit-code
git diff --cached --exit-code
printf "SDK152_COMMIT_HEAD=%s COMMIT_TREE=%s\n" "$(git rev-parse HEAD)" "$SDK_TREE"
git bundle create "$FORK/verification-state/sdk152-gates.bundle" refs/heads/lue/t-pi-151-sdk-1110 ^"$SDK_BASE" ^"$SDK_MAIN"
sha256sum "$FORK/verification-state/sdk152-gates.bundle"
echo CRABBOX_PHASE:finished-status-0
