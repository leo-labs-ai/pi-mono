#!/usr/bin/env bash
set -euo pipefail
if ! command -v node >/dev/null; then
  mkdir -p "$HOME/.node"
  curl -fsSL https://nodejs.org/dist/v24.22.1/node-v24.22.1-linux-x64.tar.gz | tar -xz -C "$HOME/.node" --strip-components=1
  export PATH="$HOME/.node/bin:$PATH"
fi
node -v
echo CRABBOX_PHASE:install
npm ci --prefer-offline --no-audit --no-fund --loglevel=error --ignore-scripts
echo CRABBOX_PHASE:hydrate
npm run hydrate:model-snapshot
echo CRABBOX_PHASE:build
npm run build:offline
status=0
echo CRABBOX_PHASE:check
npm run check || status=1
echo CRABBOX_PHASE:build-gate
GATE_HOME=$(mktemp -d)
env -i PATH="$PATH" HOME="$GATE_HOME" PI_NO_LOCAL_LLM=1 AWS_EC2_METADATA_DISABLED=true npm run test:build-gate || status=1
echo CRABBOX_PHASE:anthropic-effort
ROOT=$PWD
(cd packages/ai && env -i PATH="$PATH" HOME="$GATE_HOME" node "$ROOT/node_modules/vitest/dist/cli.js" --run test/anthropic-mid-conversation-effort.test.ts) || status=1
echo CRABBOX_PHASE:p2-check
(cd apps/p2 && npm run check) || status=1
echo CRABBOX_PHASE:p2-plugin-layout
(cd apps/p2 && env -i PATH="$PATH" HOME="$GATE_HOME" node --import ./src/source.ts --test test/p2/plugin-layout.test.ts) || status=1
echo CRABBOX_PHASE:finished-status-$status
exit "$status"
