#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.node/bin:$HOME/.local/bin:$PATH"
node -v
FORK=$PWD
D=$FORK/verification-state/sdk-input
echo CRABBOX_PHASE:committed-sdk
actual=$(git hash-object -t commit -w --stdin < "$D/fork-candidate.commit")
test "$actual" = 63f5393b643e6882998770fba62815cabaab15ee
git update-ref refs/heads/verification-candidate "$actual"
git symbolic-ref HEAD refs/heads/verification-candidate
test "$(git rev-parse HEAD^{tree})" = 3322f9c1a19747d394de852b145390e429271ca2
test -z "$(git status --porcelain --untracked-files=no)"
printf 'SDK_HEAD=%s SDK_TREE=%s\n' "$(git rev-parse HEAD)" "$(git write-tree)"
cd ..
test ! -e pi-mono-fork
ln -s pi-mono pi-mono-fork
test ! -e my-pi
mkdir my-pi
cd my-pi
tar -xf "$D/my-pi-base.tar" --no-same-owner
git init -b sdk-verification
git apply "$D/my-pi-candidate.patch"
git add -f --pathspec-from-file="$D/my-pi-tracked-paths.nul" --pathspec-file-nul
test "$(git write-tree)" = cb21e5f1a245ed5ead2c83a7dd5a28a08962145e
echo MY_PI_TREE=cb21e5f1a245ed5ead2c83a7dd5a28a08962145e
echo CRABBOX_PHASE:my-pi-fresh-install
npm ci --prefer-offline --no-audit --no-fund --loglevel=error --ignore-scripts
status=0
echo CRABBOX_PHASE:workspace-resolution
npm run verify:workspace-resolution || status=1
echo CRABBOX_PHASE:workspace-typecheck
npm run typecheck || status=1
echo CRABBOX_PHASE:lint
npm run lint || status=1
echo CRABBOX_PHASE:test-registration
npm run check:test-registration || status=1
echo CRABBOX_PHASE:workflow-tests
TEST_HOME=$(mktemp -d)
env -i PATH="$PATH" HOME="$TEST_HOME" node --test test/release-workflow.test.mjs test/agentic-review-baked-pi-version.test.mjs test/sdk-workflow-build-route.test.mjs || status=1
echo CRABBOX_PHASE:payload-stability
git diff --exit-code || status=1
test "$(git write-tree)" = cb21e5f1a245ed5ead2c83a7dd5a28a08962145e || status=1
echo CRABBOX_PHASE:finished-status-$status
exit "$status"
